CREATE PROCEDURE dump()
  BEGIN
  DECLARE fnl, k INT;
  
  DECLARE cur CURSOR FOR SELECT salary FROM salaries;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET fnl = 1;
  
  CREATE TABLE IF NOT EXISTS dump (
    salary INT
  );
  TRUNCATE TABLE dump;
 
  OPEN cur;
    SET fnl = 0;
  
    WHILE fnl = 0 DO
      FETCH cur INTO k;
      INSERT INTO dump(salary) VALUES(k);
    END WHILE;
  CLOSE cur;
END;
