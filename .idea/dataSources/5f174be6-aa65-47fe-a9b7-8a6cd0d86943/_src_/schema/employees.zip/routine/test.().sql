CREATE PROCEDURE test()
  BEGIN
    DECLARE val INT;
    SET val = 10000;
  INSERT INTO salaries(emp_no, salary, from_date, to_date)
    VALUES (100500, val, NOW(), NOW());
  END;
