CREATE PROCEDURE test(IN emp INT, IN val INT, IN `from` DATE, IN `to` DATE, OUT var INT)
  BEGIN 
    SET var = 42;
    INSERT INTO salaries(emp_no, salary, from_date, to_date)
    VALUES (emp, val, `from`, `to`);
  END;
