CREATE VIEW dep_sal AS
  SELECT
    `d`.`dept_name`   AS `dept_name`,
    avg(`s`.`salary`) AS `salary`
  FROM ((`employees`.`departments` `d` LEFT JOIN `employees`.`dept_emp` `de`
      ON ((`d`.`dept_no` = `de`.`dept_no`))) LEFT JOIN `employees`.`salaries` `s` ON ((`s`.`emp_no` = `de`.`emp_no`)))
  GROUP BY `d`.`dept_name`;
